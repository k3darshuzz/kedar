function logo(){
	arlet('View Educaional progress of Tinashe');
	document.write('Went to Tadzembwa Primary School\n'+'\n Went to Shingai Primary School Chiredzi\n'+
	'\n Went to Chirowakamwe Primary School\n'+'\n Went to Zimuto High School\n'+'\n Went to Mutendi High School \n'+
	'\n Currently Studying at HIT \n');
	
}